<?php
/**
 * DB satırlarını (snake_case) frontend TS tiplerine (camelCase) dönüştürür.
 * Tip kaynakları: src/types/index.ts
 * KRİTİK: dış kimlikler `code`/`slug` üzerinden korunur; id alanı TS'te string'tir,
 * bu yüzden eski string id'yi (code) `id` olarak döndürüyoruz ki frontend hiç değişmesin.
 */
declare(strict_types=1);

/** Yazar { id, ad, soyad, tamAd, fotograf?, biyografi? } */
function yazar_out(?array $r): ?array
{
    if (!$r) return null;
    return [
        'id'        => (string)$r['code'],
        'ad'        => $r['ad'],
        'soyad'     => $r['soyad'],
        'tamAd'     => $r['tam_ad'],
        'fotograf'  => $r['fotograf'] ?? null,
        'biyografi' => $r['biyografi'] ?? null,
    ];
}

/**
 * Menü öğesi { id, parentId, gorunenBaslik, sistemBaslik, tur, hedef, sira,
 *              aktif, otomatik, yeniSekme }. children ağaç kurucuda eklenir.
 * id/parentId frontend'de string (menuler.id numeric AUTO_INCREMENT).
 */
function menu_out(array $r): array
{
    return [
        'id'            => (string)$r['id'],
        'parentId'      => $r['parent_id'] !== null ? (string)$r['parent_id'] : null,
        'gorunenBaslik' => $r['gorunen_baslik'],
        'sistemBaslik'  => $r['sistem_baslik'] ?? null,
        'tur'           => $r['tur'],
        'hedef'         => $r['hedef'] ?? null,
        'sira'          => (int)$r['sira'],
        'aktif'         => (bool)(int)$r['aktif'],
        'otomatik'      => (bool)(int)$r['otomatik'],
        'yeniSekme'     => (bool)(int)$r['yeni_sekme'],
    ];
}

/**
 * Ana sayfa bloğu { id, tip, baslik, sira, aktif, ayar }.
 * ayar DB'de JSON metnidir; çözülüp obje olarak döndürülür (bozuksa {}).
 */
function anasayfa_blok_out(array $r): array
{
    $ayar = [];
    if (!empty($r['ayar'])) {
        $d = json_decode((string)$r['ayar'], true);
        if (is_array($d)) $ayar = $d;
    }
    return [
        'id'     => (string)$r['id'],
        'tip'    => $r['tip'],
        'baslik' => $r['baslik'] ?? '',
        'sira'   => (int)$r['sira'],
        'aktif'  => (bool)(int)$r['aktif'],
        'ayar'   => (object)$ayar,
    ];
}

/**
 * Statik sayfa { slug, baslik, kisaAciklama, icerik, seoBaslik, seoAciklama,
 *               yayinDurumu, sira }. Yeni kolonlar migration öncesi yoksa
 * güvenli varsayılanlara düşer (?? ile undefined-key uyarısı da bastırılır).
 */
function sayfa_out(array $r): array
{
    return [
        'slug'         => $r['slug'],
        'baslik'       => $r['baslik'],
        'kisaAciklama' => $r['kisa_aciklama'] ?? '',
        'icerik'       => $r['icerik'] ?? '',
        'seoBaslik'    => $r['seo_baslik'] ?? '',
        'seoAciklama'  => $r['seo_aciklama'] ?? '',
        'yayinDurumu'  => $r['yayin_durumu'] ?? 'yayinda',
        'sira'         => isset($r['sira']) ? (int)$r['sira'] : 0,
    ];
}

/**
 * Filtre sayfası { id, slug, baslik, aciklama, kategori, siralama, sayfaBasina,
 *                 kapakGoster, yazarTarihGoster, aktif, sira }.
 */
function filtre_sayfa_out(array $r): array
{
    return [
        'id'               => (string)$r['id'],
        'slug'             => $r['slug'],
        'baslik'           => $r['baslik'],
        'aciklama'         => $r['aciklama'] ?? '',
        'geriBaslik'       => $r['geri_baslik'] ?? null,   // geri butonu metni (boşsa "Ana Sayfa")
        'geriHedef'        => $r['geri_hedef'] ?? null,    // geri butonu hedefi (yerleşik sayfa)
        'kategori'         => $r['kategori'] ?? '',
        'siralama'         => $r['siralama'] ?? 'yeni',
        'sayfaBasina'      => isset($r['sayfa_basina']) ? (int)$r['sayfa_basina'] : 12,
        'kapakGoster'      => isset($r['kapak_goster']) ? (bool)(int)$r['kapak_goster'] : true,
        'yazarTarihGoster' => isset($r['yazar_tarih_goster']) ? (bool)(int)$r['yazar_tarih_goster'] : true,
        'aktif'            => isset($r['aktif']) ? (bool)(int)$r['aktif'] : true,
        'sira'             => isset($r['sira']) ? (int)$r['sira'] : 0,
    ];
}

/** Kategori { id, ad, slug, sira, aktif } */
function kategori_out(?array $r): ?array
{
    if (!$r) return null;
    return [
        'id'    => (string)$r['code'],
        'ad'    => $r['ad'],
        'slug'  => $r['slug'],
        'sira'  => isset($r['sira_no']) ? (int)$r['sira_no'] : 0,
        'aktif' => isset($r['aktif']) ? (bool)(int)$r['aktif'] : true,
    ];
}

/**
 * Yazi { id, baslik, spot?, icerik?, yazar, kategori, sayiId, siraNo, pdfUrl?, kapakGorseli?, yayinTarihi? }
 * $yazar ve $kategori önceden serileştirilmiş (gömülü) objelerdir.
 */
function yazi_out(array $r, ?array $yazar, ?array $kategori, string $sayiCode): array
{
    return [
        'id'           => (string)$r['code'],
        'baslik'       => $r['baslik'],
        'spot'         => $r['spot'] ?? null,
        'icerik'       => $r['icerik'] ?? null,
        'yazar'        => $yazar,
        'kategori'     => $kategori,
        'sayiId'       => $sayiCode,
        'siraNo'       => (int)$r['sira_no'],
        'pdfUrl'       => $r['pdf_url'] ?? null,
        'kapakGorseli' => $r['kapak_gorseli'] ?? null,
        'yayinTarihi'  => $r['yayin_tarihi'] ?? null,
    ];
}

/**
 * Sayi { id, numara, ay, yil, tamBaslik, kapakGorseli, pdfUrl, kunye?, onsoz?,
 *        durum, editorId?, editorAd?, yazilar[], yayinTarihi }
 * $yazilar önceden serileştirilmiş Yazi[] dizisidir.
 * durum/editor alanları $r'de yoksa güvenli varsayılanlara düşer (geriye dönük uyum).
 * editor_ad alanı yalnızca kullanicilar ile JOIN yapılan sorgularda bulunur.
 */
function sayi_out(array $r, array $yazilar): array
{
    return [
        'id'           => (string)$r['code'],
        'numara'       => $r['numara'],
        'ay'           => $r['ay'],
        'yil'          => (int)$r['yil'],
        'tamBaslik'    => $r['tam_baslik'] ?? '',
        // Menü/ana sayfa alanları: kolonlar migration öncesi yoksa güvenli varsayılanlar.
        'menuEtiket'      => $r['menu_etiket'] ?? null,
        'menuGoster'      => isset($r['menu_goster']) ? (bool)(int)$r['menu_goster'] : true,
        'anasayfaGoster'  => isset($r['anasayfa_goster']) ? (bool)(int)$r['anasayfa_goster'] : false,
        'kapakGorseli' => $r['kapak_gorseli'] ?? '',
        'pdfUrl'       => $r['pdf_url'] ?? '',
        'kunye'        => $r['kunye'] ?? null,
        'onsoz'        => $r['onsoz'] ?? null,
        'durum'        => $r['durum'] ?? 'yayinda',
        'editorId'     => isset($r['editor_id']) && $r['editor_id'] !== null ? (string)$r['editor_id'] : null,
        'editorAd'     => $r['editor_ad'] ?? null,
        'yazilar'      => $yazilar,
        'yayinTarihi'  => $r['yayin_tarihi'] ?? '',
    ];
}

/** ArsivSayi { id, numara, ay, yil, kapakGorseli, pdfUrl, yayinTarihi, menuEtiket?, menuGoster?, anasayfaGoster? } */
function arsiv_out(array $r): array
{
    return [
        'id'           => (string)$r['code'],
        'numara'       => $r['numara'],
        'ay'           => $r['ay'],
        'yil'          => (int)$r['yil'],
        'kapakGorseli' => $r['kapak_gorseli'] ?? '',
        'pdfUrl'       => $r['pdf_url'] ?? '',
        'yayinTarihi'  => $r['yayin_tarihi'] ?? '',
        'menuEtiket'     => $r['menu_etiket'] ?? null,
        'menuGoster'     => isset($r['menu_goster']) ? (bool)(int)$r['menu_goster'] : true,
        'anasayfaGoster' => isset($r['anasayfa_goster']) ? (bool)(int)$r['anasayfa_goster'] : false,
    ];
}

/**
 * AraYazi { id, baslik, spot, icerik, yazar, kategori(STRING), kategoriler(STRING[]),
 *           kapakGorseli?, yayinTarihi, slug }
 * kategori (birincil, kart etiketi) = kategori_ad. kategoriler = tüm kategoriler
 * (çoklu kategori; $kategoriler null ise birincil kategoriye düşer).
 * $includeIcerik=false ise liste görünümünde ağır HTML gövdesi atlanır.
 */
function ara_yazi_out(array $r, ?array $yazar, bool $includeIcerik = true, ?array $kategoriler = null): array
{
    $birincil = $r['kategori_ad'] ?? '';
    $katListe = $kategoriler !== null && count($kategoriler) > 0
        ? $kategoriler
        : ($birincil !== '' ? [$birincil] : []);
    $out = [
        'id'           => (string)$r['code'],
        'baslik'       => $r['baslik'],
        'spot'         => $r['spot'] ?? '',
        'yazar'        => $yazar,
        'kategori'     => $birincil,   // birincil kategori (kart etiketi)
        'kategoriler'  => $katListe,   // tüm kategoriler (çoklu)
        'kapakGorseli' => $r['kapak_gorseli'] ?? null,
        'yayinTarihi'  => $r['yayin_tarihi'] ?? '',
        'tarihEtiketi' => $r['tarih_etiketi'] ?? null,   // serbest metin tarih (varsa kartta bu görünür)
        'slug'         => $r['slug'],
    ];
    if ($includeIcerik) {
        $out['icerik'] = $r['icerik'] ?? '';
    }
    return $out;
}

/**
 * Kullanici { id, username, role, name, email?, isActive, lastLoginAt? }
 * password_hash ASLA döndürülmez.
 */
function kullanici_out(array $r): array
{
    return [
        'id'          => (string)$r['id'],
        'username'    => $r['username'],
        'role'        => $r['role'],
        'name'        => $r['name'],
        'email'       => $r['email'] ?? null,
        'isActive'    => (bool)((int)$r['is_active']),
        'lastLoginAt' => $r['last_login_at'] ?? null,
    ];
}

/** Editör seçim listesi için hafif çıktı { id, name, role } (atama açılır menüsü). */
function editor_out(array $r): array
{
    return [
        'id'   => (string)$r['id'],
        'name' => $r['name'],
        'role' => $r['role'],
    ];
}
